#ifndef SRTF_H
#define SRTF_H

#include<iostream>
#include "Process.h"
#include<limits.h>
#include "CPUfunctions.h"
using namespace std;

void SRTF(Process *,int);
int getShortestProcess(Process* ,int,int);
#endif


