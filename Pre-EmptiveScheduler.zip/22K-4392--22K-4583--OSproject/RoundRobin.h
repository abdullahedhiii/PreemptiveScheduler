#ifndef ROUNDROBIN_H
#define ROUND_ROBIN_H

#include<iostream>
#include "Process.h"
#include "CPUfunctions.h"
using namespace std;

void roundRobin(Process *,int,int);

#endif


